package com.example.apnuamdavad.Model;

public class BusRoute {

    String bus_id,bus_no,source_title,source_lat,source_long,destination_title,destination_lat,destination_long;

    public String getBus_id() {
        return bus_id;
    }

    public void setBus_id(String bus_id) {
        this.bus_id = bus_id;
    }

    public String getBus_no() {
        return bus_no;
    }

    public void setBus_no(String bus_no) {
        this.bus_no = bus_no;
    }

    public String getSource_title() {
        return source_title;
    }

    public void setSource_title(String source_title) {
        this.source_title = source_title;
    }

    public String getSource_lat() {
        return source_lat;
    }

    public void setSource_lat(String source_lat) {
        this.source_lat = source_lat;
    }

    public String getSource_long() {
        return source_long;
    }

    public void setSource_long(String source_long) {
        this.source_long = source_long;
    }

    public String getDestination_title() {
        return destination_title;
    }

    public void setDestination_title(String destination_title) {
        this.destination_title = destination_title;
    }

    public String getDestination_lat() {
        return destination_lat;
    }

    public void setDestination_lat(String destination_lat) {
        this.destination_lat = destination_lat;
    }

    public String getDestination_long() {
        return destination_long;
    }

    public void setDestination_long(String destination_long) {
        this.destination_long = destination_long;
    }
}
