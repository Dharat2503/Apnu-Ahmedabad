package com.example.apnuamdavad.Listener;

import com.example.apnuamdavad.Model.Category;
import com.example.apnuamdavad.Place_master;

import java.util.ArrayList;

public interface PlaceitemClickListener {

  public void setOnItemClicked(ArrayList<Category> listCategory, int position);
}
