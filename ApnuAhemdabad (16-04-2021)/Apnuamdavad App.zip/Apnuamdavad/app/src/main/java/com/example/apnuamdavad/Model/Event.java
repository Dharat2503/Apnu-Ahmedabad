package com.example.apnuamdavad.Model;

public class Event {
  String Event_type_id,Event_type_name;

  public String getEvent_type_id() {
    return Event_type_id;
  }

  public void setEvent_type_id(String event_type_id) {
    Event_type_id = event_type_id;
  }

  public String getEvent_type_name() {
    return Event_type_name;
  }

  public void setEvent_type_name(String event_type_name) {
    Event_type_name = event_type_name;
  }
}
