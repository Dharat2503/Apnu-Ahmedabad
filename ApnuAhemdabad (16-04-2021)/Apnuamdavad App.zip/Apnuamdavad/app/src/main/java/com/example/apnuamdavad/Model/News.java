package com.example.apnuamdavad.Model;

public class News {

  String News_id,news_title,News_details,News_date,News_photo;

  public String getNews_id() {
    return News_id;
  }

  public void setNews_id(String news_id) {
    News_id = news_id;
  }

  public String getNews_title() {
    return news_title;
  }

  public void setNews_title(String news_title) {
    this.news_title = news_title;
  }

  public String getNews_details() {
    return News_details;
  }

  public void setNews_details(String news_details) {
    News_details = news_details;
  }

  public String getNews_date() {
    return News_date;
  }

  public void setNews_date(String news_date) {
    News_date = news_date;
  }

  public String getNews_photo() {
    return News_photo;
  }

  public void setNews_photo(String news_photo) {
    News_photo = news_photo;
  }
}
