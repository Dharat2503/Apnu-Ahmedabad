package com.example.apnuamdavad.Model;

public class Place {
  String Place_id,Place_title,Category_id,Place_details,Place_img_path;

  public String getPlace_id() {
    return Place_id;
  }

  public void setPlace_id(String place_id) {
    Place_id = place_id;
  }

  public String getPlace_title() {
    return Place_title;
  }

  public void setPlace_title(String place_title) {
    Place_title = place_title;
  }

  public String getCategory_id() {
    return Category_id;
  }

  public void setCategory_id(String category_id) {
    Category_id = category_id;
  }

  public String getPlace_details() {
    return Place_details;
  }

  public void setPlace_details(String place_details) {
    Place_details = place_details;
  }

  public String getPlace_img_path() {
    return Place_img_path;
  }

  public void setPlace_img_path(String place_img_path) {
    Place_img_path = place_img_path;
  }
}
