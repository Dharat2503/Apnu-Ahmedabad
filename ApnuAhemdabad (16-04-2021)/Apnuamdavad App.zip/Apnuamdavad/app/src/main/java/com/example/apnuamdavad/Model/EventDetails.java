package com.example.apnuamdavad.Model;

public class EventDetails {

    String Event_id,Event_type_id,Event_type_name,Event_name,Event_location,Event_details,Event_photo_path;

    public String getEvent_id() {
        return Event_id;
    }

    public void setEvent_id(String event_id) {
        Event_id = event_id;
    }

    public String getEvent_type_id() {
        return Event_type_id;
    }

    public void setEvent_type_id(String event_type_id) {
        Event_type_id = event_type_id;
    }

    public String getEvent_type_name() {
        return Event_type_name;
    }

    public void setEvent_type_name(String event_type_name) {
        Event_type_name = event_type_name;
    }

    public String getEvent_name() {
        return Event_name;
    }

    public void setEvent_name(String event_name) {
        Event_name = event_name;
    }

    public String getEvent_location() {
        return Event_location;
    }

    public void setEvent_location(String event_location) {
        Event_location = event_location;
    }

    public String getEvent_details() {
        return Event_details;
    }

    public void setEvent_details(String event_details) {
        Event_details = event_details;
    }

    public String getEvent_photo_path() {
        return Event_photo_path;
    }

    public void setEvent_photo_path(String event_photo_path) {
        Event_photo_path = event_photo_path;
    }
}
