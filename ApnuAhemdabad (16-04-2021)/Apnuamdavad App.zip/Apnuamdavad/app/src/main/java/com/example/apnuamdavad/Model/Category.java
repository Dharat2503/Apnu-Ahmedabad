package com.example.apnuamdavad.Model;

public class Category {

  String Category_id,Category_name,Category_photo_path;

  public String getCategory_id() {
    return Category_id;
  }

  public void setCategory_id(String category_id) {
    Category_id = category_id;
  }

  public String getCategory_name() {
    return Category_name;
  }

  public void setCategory_name(String category_name) {
    Category_name = category_name;
  }

  public String getCategory_photo_path() {
    return Category_photo_path;
  }

  public void setCategory_photo_path(String category_photo_path) {
    Category_photo_path = category_photo_path;
  }
}
