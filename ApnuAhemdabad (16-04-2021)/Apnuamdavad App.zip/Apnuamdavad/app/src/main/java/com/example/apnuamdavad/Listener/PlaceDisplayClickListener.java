package com.example.apnuamdavad.Listener;

import com.example.apnuamdavad.Model.Category;
import com.example.apnuamdavad.Model.Place;

import java.util.ArrayList;

public interface PlaceDisplayClickListener {
    public void setOnItemClicked(ArrayList<Place> listPlaceMaster, int position);

}
